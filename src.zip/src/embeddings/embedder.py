import os
import sys
import subprocess
import warnings 

try:
    import numpy as np  # type: ignore
    from dotenv import load_dotenv  # type: ignore
    from google import genai  # type: ignore
except ImportError:
    subprocess.check_call([sys.executable, "-m", "pip", "install", "python-dotenv", "numpy", "google-generativeai", "pinecone"])
    import numpy as np  # type: ignore
    from dotenv import load_dotenv  # type: ignore
    from google import genai  # type: ignore

# Suppress the large FutureWarning from google.genai so it doesn't look like an error
warnings.filterwarnings("ignore", category=FutureWarning)

# Load all private environment variables from the .env file
load_dotenv()

# Read the Gemini key from the environment variables safely
API_KEY = os.getenv("GEMINI_API_KEY")

# Initialize the Google Generative AI client with the API key
if API_KEY:
    client = genai.Client(api_key=API_KEY)
else:
    print("Warning: GEMINI_API_KEY was not found in the environment variables.")
    client = None

def get_embedding(text: str) -> list[float] | None:
    """
    Takes a string of regular text and returns a vector (a list of decimal numbers).
    The vector captures the semantic meaning of the text.
    
    If the text cannot be converted due to a network or API error,
    it prints the error clearly and returns None instead of crashing.
    """
    if not text.strip():
        print("Error: The text provided is completely empty.")
        return None
        
    try:
        # Ask Google's API to construct a semantic vector from the text.
        # We use the gemini-embedding-2-preview model (newer than embedding-001).
        response = client.models.embed_content(
            model="models/gemini-embedding-2-preview",
            contents=text,
        )
        # Extract and return the actual list of float values.
        # google.genai returns a list of embeddings with a 'values' attribute
        return response.embeddings[0].values
    except Exception as e:
        # Catch unexpected problems so the rest of the program doesn't fail
        print(f"Failed to generate an embedding for text: {e}")
        return None

def get_similarity(vec1: list[float], vec2: list[float]) -> float:
    """
    Takes two vector lists and returns how similar their semantic meanings are.
    The similarity score is given as a decimal value mathematically between 0.0 and 1.0, 
    where 1.0 means perfectly identical.

    It calculates this using the cosine similarity formula mathematically.
    """
    # Convert standard Python lists to NumPy arrays to allow faster vector math operations
    np_v1 = np.array(vec1, dtype=float)
    np_v2 = np.array(vec2, dtype=float)
    
    # Calculate the dot product (multiplying corresponding dimensions and summing them)
    dot_product = np.dot(np_v1, np_v2)
    
    # Calculate the magnitude/length (norm) of each vector mathematically
    norm_v1 = np.linalg.norm(np_v1)
    norm_v2 = np.linalg.norm(np_v2)
    
    # If someone accidentally passed in a zero-vector, avoid the divide-by-zero crash
    if norm_v1 == 0 or norm_v2 == 0:
        return 0.0
        
    # Standard formula for cosine similarity between two vectors 
    # (Results technically range between -1.0 and 1.0 mathematically)
    cos_sim = dot_product / (norm_v1 * norm_v2)
    
    # Since text similarities in embeddings often don't truly go negative 
    # and the requirements mandate a float between 0 and 1, we clip the bounds.
    # min()/max() handles potential math rounding issues producing numbers like 1.0000000002
    bounded_sim = max(0.0, min(1.0, cos_sim))
    
    # Convert the numpy float back to a regular Python float
    return float(bounded_sim)
