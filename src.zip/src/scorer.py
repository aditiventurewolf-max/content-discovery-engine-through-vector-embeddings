import json
import os
from dotenv import load_dotenv
from google import genai

load_dotenv()
API_KEY = os.getenv("GEMINI_API_KEY")
client = genai.Client(api_key=API_KEY)

SYSTEM_PROMPT = """You are a content scoring engine for a 20-year-old who reads to have his thinking reframed, not informed. Score on idea_novelty (35%), intellectual_density (30%), topic_resonance (20%), voice_authenticity (15%). Return only JSON: {"idea_novelty":0,"intellectual_density":0,"topic_resonance":0,"voice_authenticity":0,"penalty":"none","final_score":0.0,"verdict":"pass|reject","reason":"one sentence"}"""

def evaluate_article(title: str, summary: str) -> dict:
    """
    Uses Gemini to score the article based on precise reframing criteria natively via JSON mode.
    """
    prompt_text = f"{SYSTEM_PROMPT}\n\nEvaluate the following article:\nTitle: {title}\nSummary: {summary}"
    
    try:
        # Use gemini-2.0-flash which supports JSON mode with the new client API
        response = client.models.generate_content(
            model="models/gemini-2.0-flash",
            contents=prompt_text,
            config={"response_mime_type": "application/json"}
        )
        
        # Load and parse the returned JSON string as a native Python dictionary
        result = json.loads(response.text)
        return result
    except Exception as e:
        print(f"  [ERROR] Scoring failed for '{title}...': {e}")
        return {"final_score": 0.0, "reason": "API error during scoring."}
